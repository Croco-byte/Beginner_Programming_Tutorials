#!/usr/bin/python
#coding: utf-8

from termcolor import colored
import hashlib
import codecs


def openFile(wordlist) :
    
    global passwdfile

    try:
        passwdfile = open(wordlist, 'r', encoding='utf-8',errors='ignore')
    except:
        print("[-] Failed to open wordlist. Please try again with a correct path.")
        quit()


passhash = input("[*] Enter md5 hash value : ")
wordlist = input("[*] Enter the path to the wordlist to use : ")
openFile(wordlist)

for word in passwdfile :
    print(colored("[*] Trying password {0}.".format(word.strip()),'red'))
    hashguess = hashlib.md5(word.encode().strip()).hexdigest()

    if hashguess == passhash :
        print(colored("[+] Found !! Password was {0}".format(word),'green'))
        exit(0)


