#!/usr/bin/python
#coding: utf-8

import hashlib

hashvalue = input("Enter a string to hash : ")      # defining the hash

resultMD5 = hashlib.md5(hashvalue.encode())         # creating the hash with md5 function. encode() converts the string into bytes in order to be acceptable by the hash function
print("MD5 hash : {0}".format(resultMD5.hexdigest()))   # the function digest() return the hash in byte format, the function hexdigest() returns it in the more readable hexadecimal format. Output of 'admin' input : 21232f297a57a5a743894a0e4a801fc3


resultSHA1 = hashlib.sha1(hashvalue.encode())
print("SHA1 hash : {0}".format(resultSHA1.hexdigest()))


resultSHA224 = hashlib.sha224(hashvalue.encode())
print("SHA244 hash : {0}".format(resultSHA224.hexdigest()))


resultSHA256 = hashlib.sha256(hashvalue.encode())
print("SHA256 hash : {0}".format(resultSHA256.hexdigest()))


resultSHA512 = hashlib.sha512(hashvalue.encode())
print("SHA512 hash : {0}".format(resultSHA512.hexdigest()))
