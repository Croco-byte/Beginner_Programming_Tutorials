#!/usr/bin/python
#coding: utf-8

import crypt

def crackPass(encrypted) :
    salt = encrypted[:2]
    
    guessFile = open("/root/Sauna/users.txt","r")
    for lines in guessFile.readlines():
        lines = lines.strip()

        guess = crypt.crypt(lines,salt)
        if guess == encrypted :
            print("[+] Password found for {0} : {1}".format(encrypted,lines))
            return



def main() :
    passwdFile = open("pass.txt","r")
    for line in passwdFile.readlines() :
        if ":" in line :
            user = line.split(":")[0]
            encrypted = line.split(":")[1].strip()
            print("[*] Cracking following password : {0}".format(encrypted))
            crackPass(encrypted)

if __name__ == '__main__' :
    main()

