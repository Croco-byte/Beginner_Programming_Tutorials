#!/usr/bin/python3
#coding:utf-8

import hashlib
import codecs
from termcolor import colored


hashToGuess = input("Enter the hash to crack using a dictionary attack : ")



with open('/root/Sauna/users.txt','r',encoding='utf-8',errors='ignore') as f :
    passwdlist = f.read().splitlines()

for i in passwdlist:
    hashguess = hashlib.sha1(i.encode()).hexdigest()
    print("Trying password {0} with corresponding hash {1}.".format(i,hashguess))

    if hashguess == hashToGuess :
        print(colored("CRACKED. Password was {0}.".format(i),'green'))
        break
