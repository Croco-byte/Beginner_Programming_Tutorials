#!/usr/bin/python
# -*- coding: utf-8 -*-

import donnees
import fonctions
import pickle


attempts = 0
gameWon = False
pseudoFound = False


print("[*] Bienvenue dans le jeu du pendu ! L'ordinateur va choisir un mot au hasard, de 8 lettres maximum. Après vous avoir donné la première et dernière lettre, vous devrez deviner les autres lettres du mot.\n")
print(" ******************************* \n")

pseudoJoueur = raw_input("Veuillez tout d'abord entrer votre pseudo : ")

with open('scores','rb') as fichier:
    depickler = pickle.Unpickler(fichier)
    score_recup = depickler.load()

for cle,valeur in score_recup.items():
    if cle == pseudoJoueur :
        pseudoFound = True
        print("Bonjour {0}. Votre score actuel est de {1}.\n".format(cle,valeur))

if pseudoFound is not True :
    print("Votre pseudo n'existe pas encore {0}. Nous allons le créer avec un score initial de 0.\n".format(pseudoJoueur))
    score_recup[pseudoJoueur] = 0
    with open('scores','wb') as fichier:
        pickler = pickle.Pickler(fichier)
        pickler.dump(score_recup)
    print("{0}, votre profil a bien été crée. Votre score est de 0.".format(pseudoJoueur))






chosenWord = fonctions.chooseRandomWord()
wordToGuess = fonctions.getWordToGuess(chosenWord)

print("[*] Le mot que vous devez deviner est le suivant : {0}".format(wordToGuess))
print("Bonne chance !\n")
print(" ******************************* \n")


while attempts < donnees.chances :
    
    while 1 :
        try :
            guessLetter = raw_input("[+] Entrez la lettre que vous voulez deviner : ") # On récupère la lettre que la personne entre

            assert len(guessLetter) == 1            # Si cette personne a rentré plus d'une lettre...
        except AssertionError :
            print("Veuillez entrez seulement une lettre s'il vous plaît.")  #On traite l'erreur sous la forme d'assertion. On reste dans la boucle while 1

        else :                  # Sinon, on prend en compte l'essai et on sort de la boucle pour continuer
            attempts += 1
            break

    scrawler = 0
    counter = 0

    while scrawler < (len(chosenWord)) :
        if guessLetter == chosenWord[scrawler] :
            counter = counter+1
            wordToGuess = fonctions.revealCharacter(wordToGuess, scrawler, chosenWord[scrawler])

        scrawler = scrawler+1

    print("\n [+] Votre lettre se trouve {0} fois dans le mot.".format(counter))
    print("\n [+] Voici désormais le mot que vous devez deviner : {0}\n".format(wordToGuess))



    if "*" in wordToGuess :
        print("Il vous reste {0} essais.\n".format(donnees.chances - attempts))
        print("********************************** \n")
    else :
        print(" *********** Vous avez gagné ! Le mot était bien {0}. ********** ".format(chosenWord))
        print(" Il vous restait {0} essais. Votre score est donc augmenté de {0} !".format(donnees.chances - attempts))
        score_recup[pseudoJoueur] = score_recup[pseudoJoueur] + (donnees.chances - attempts)

        with open('scores','wb') as fichier:
            pickler = pickle.Pickler(fichier)
            pickler.dump(score_recup)    

        print("********** Votre score est de {0} **********".format(score_recup[pseudoJoueur]))

        gameWon = True
        break

if gameWon is not True :
    print("\n Vous êtes arrivé au bout de vos {0} essais. Game Over.".format(donnees.chances))
    print("Le mot était : {0}.\n".format(chosenWord))

        


