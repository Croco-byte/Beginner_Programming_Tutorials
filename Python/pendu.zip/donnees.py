#!/usr/bin/python
# -*- coding: utf-8 -*-

mots = ["bonjour", "voiture", "travail", "python", "course", "jouer", "pendu", "vendre", "cours", "tableau"]

chances = 8
