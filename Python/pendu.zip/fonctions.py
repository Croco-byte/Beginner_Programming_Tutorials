#!/usr/bin/python
# -*- coding: utf-8 -*-

import donnees
import random

def chooseRandomWord() :
    chosenWord = random.choice(donnees.mots)    #On choisit au hasard un mot de la liste de mots définie dans le fichier donnees
    return chosenWord



def getWordToGuess(chosenWord) :

    firstLetter = chosenWord[0]
    lastLetter = chosenWord[-1]
    middleLetters = "*"*(len(chosenWord)-2)

    wordToGuess = firstLetter + middleLetters + lastLetter #Le mot à deviner se compose de la première lettre du mot choisi, puis d'autant d'étoiles qu'il y a de lettres avant la dernière lettre du mot, puis de la dernière lettre du mot.


    return wordToGuess


def revealCharacter(string, position, character) :
    return string[:position] + character + string[position+1:]

